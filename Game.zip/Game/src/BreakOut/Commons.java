package breakout;

public interface Commons {
    public static final int WIDTH = 300;
    public static final int HEIGTH = 400;
    public static final int BOTTOM = 390;
    public static final int PADDLE_RIGHT = 250;
    public static final int BALL_RIGHT = 280;
}
